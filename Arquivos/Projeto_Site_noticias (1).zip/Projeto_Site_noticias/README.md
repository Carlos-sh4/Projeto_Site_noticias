# Portal de Notícias

Projeto da turma de Banco de Dados (Estácio Arapiraca). O site lê as notícias de um banco SQL Server por meio de uma API em Python (FastAPI).

```
frontend/   páginas do site (HTML, CSS, JS, imagens)
backend/    API em Python que consulta o SQL Server e também entrega o site
database/   scripts SQL e a planilha de carga inicial
coletor/    script que busca notícias numa API todo dia e grava no banco
```

Hoje vêm do banco a **home** e as **8 páginas de categoria** (Esportes, Economia, Política, Brasil, Mundo, Saúde, Tecnologia e Entretenimento). Login, cadastro, comentários e Fale Conosco ainda funcionam só no navegador. Ficam para as próximas etapas.

## Como rodar no seu PC (Windows)

### 1. Banco de dados

No SSMS, rode os scripts da pasta `database/` em ordem:

| Script | O que faz |
|---|---|
| `00_criar_banco.sql` | cria o banco `SiteNoticias` (pule se já tiver um banco) |
| `01_criacao_tabelas.sql` | cria Usuario, Categorias, Posts e Comentarios (pule se as tabelas já existirem) |
| `02_categorias.sql` | cadastra as 8 categorias com os nomes do menu do site |
| `03_posts_exemplo.sql` | opcional: notícias de exemplo para ver o site funcionando |

Se o banco tiver outro nome, troque o `USE SiteNoticias` no topo de cada script.

### 2. Backend

Abra o terminal na pasta `backend` e rode:

```
python -m venv .venv
.venv\Scripts\python -m pip install -r requirements.txt
copy .env.exemplo .env
```

Abra o `.env` e ajuste `DB_SERVER` e `DB_NAME`. Se você entra no SSMS com o login do Windows, deixe `DB_TRUSTED=sim`. Para descobrir qual driver ODBC está instalado:

```
.venv\Scripts\python -c "import pyodbc; print(pyodbc.drivers())"
```

Use o nome que aparecer (ex.: `ODBC Driver 17 for SQL Server`) em `DB_DRIVER`. Se a lista vier vazia, instale o "ODBC Driver 18 for SQL Server" da Microsoft.

Depois suba a API:

```
.venv\Scripts\python -m uvicorn app.main:app --reload
```

### 3. Abrir o site

- Site: http://localhost:8000
- Teste de conexão com o banco: http://localhost:8000/api/saude (deve mostrar `"banco": "ok"`)
- Documentação da API, com botão para testar cada rota: http://localhost:8000/docs

Se o site for aberto sem o backend (clicando no HTML ou pelo Live Server), ele mostra as notícias de exemplo que estão escritas no próprio HTML. O Live Server (porta 5500) também funciona com o backend ligado: as páginas buscam a API em `localhost:8000`.

## API

| Rota | Retorna |
|---|---|
| `GET /api/posts?categoria=Economia&inicio=0&limite=10` | notícias mais recentes primeiro, com `total` para paginação. Sem `categoria`, traz de todas |
| `GET /api/posts/{id}` | uma notícia |
| `GET /api/categorias` | categorias e quantas notícias cada uma tem |
| `GET /api/saude` | se a API e o banco estão respondendo |

O filtro de categoria ignora acento e maiúscula: `politica`, `Política` e `POLITICA` trazem o mesmo resultado.

## Cadastrando notícias

Toda linha nova em `Posts` aparece no site na hora, sem mexer no HTML. Você pode usar a planilha `database/Carga_Inicial_Site_Noticias.xlsx` ou fazer um INSERT direto. Os campos que o site usa:

- `Titulo_Post` e `Resumo`
- `URL_Post`: o link de "Ler matéria" (abre a matéria na fonte original)
- `URL_Imagem`: link de imagem ou caminho local, como `img/foto 01.jpeg`. Se ficar vazio, o site mostra uma imagem padrão com o nome da categoria
- `Fonte`: aparece na etiqueta do card nas páginas de categoria
- `ID_Categoria`: define em que página a notícia aparece
- `DataPublicacao`: define a ordem, da mais nova para a mais antiga

## Como a página sabe onde colocar cada notícia

O arquivo `frontend/js/noticias.js` procura estas marcações no HTML:

```html
<main data-categoria="Economia">                 <!-- categoria da página; sem ele = todas (home) -->
<article data-noticia="destaque">                <!-- card grande: recebe a notícia mais recente -->
<div data-noticias="lista">                      <!-- grade: o 1º <article> serve de molde para os outros -->
data-campo="titulo | resumo | imagem | link | rotulo | data"
```

Para mudar o visual de um card, basta editar o HTML. O script só troca os textos, a imagem e o link. Para criar uma página de categoria nova, copie uma existente e troque o `data-categoria`.

## Testes

```
.venv\Scripts\python -m pip install -r requirements-dev.txt
.venv\Scripts\python -m pytest
```

Os testes não precisam de SQL Server: usam um banco falso e conferem a sintaxe T-SQL das consultas. Os do coletor rodam com `python -m pytest` dentro da pasta `coletor`.

## Coletor diário de notícias

`coletor/coletor.py` busca as notícias do dia na [GNews](https://gnews.io) (8 categorias, até 10 notícias cada) e grava as novas em `Posts`. Ele não grava a mesma URL duas vezes, nem o mesmo título dentro de 3 dias.

1. Crie uma chave grátis em https://gnews.io
2. Na pasta `coletor`: `copy .env.exemplo .env` e preencha `GNEWS_API_KEY`. O banco vem do `backend/.env`.
3. Teste sem gravar: `..\backend\.venv\Scripts\python coletor.py --simular`
4. Rode de verdade: `..\backend\.venv\Scripts\python coletor.py`

Para rodar todo dia, escolha um dos dois:

- **Agendador de Tarefas do Windows** (recomendado; roda mesmo sem terminal aberto):
  ```
  schtasks /Create /TN "Coletor Portal Noticias" /SC DAILY /ST 07:00 /TR "\"C:\caminho\backend\.venv\Scripts\python.exe\" \"C:\caminho\coletor\coletor.py\""
  ```
- **Deixar rodando:** `..\backend\.venv\Scripts\python coletor.py --loop --hora 07:00 --agora`

O registro de cada coleta fica em `coletor/logs/coletor.log`. O plano grátis da GNews entrega as notícias com 12 horas de atraso e é para desenvolvimento e testes.

## Colocando online (próximo passo)

O backend já lê tudo de variáveis de ambiente, então para publicar basta:

1. Ter um SQL Server acessível pela internet (ex.: Azure SQL Database) e rodar os scripts nele.
2. Hospedar o backend preenchendo as mesmas variáveis do `.env`, com `DB_TRUSTED=nao`, `DB_USER` e `DB_PASSWORD`. A hospedagem precisa ter o driver ODBC da Microsoft (em geral via Docker).
3. Se o site ficar num endereço e a API em outro, coloque `<meta name="api-base" content="https://endereco-da-api">` nas páginas e esse endereço do site em `CORS_ORIGENS`.
