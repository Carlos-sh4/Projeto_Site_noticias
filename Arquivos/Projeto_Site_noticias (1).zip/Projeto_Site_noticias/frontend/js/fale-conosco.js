document.addEventListener('DOMContentLoaded', () => {
    // Envio do formulário (front-end apenas; sem backend conectado ainda)
    // (o menu mobile agora é controlado por js/nav.js)
    const form = document.getElementById('form-contato');
    const sucesso = document.getElementById('mensagem-sucesso');
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        sucesso.classList.remove('hidden');
        form.reset();
        sucesso.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    });
});
