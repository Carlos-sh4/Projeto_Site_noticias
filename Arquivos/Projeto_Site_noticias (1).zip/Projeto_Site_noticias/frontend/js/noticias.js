// Preenche a página com as notícias do banco (via API do backend).
//
// Como a página "avisa" o que preencher:
//   <main data-categoria="Economia">          -> categoria da página (sem o atributo = todas, usado na home)
//   <article data-noticia="destaque">         -> card grande; recebe a notícia mais recente
//   <div data-noticias="lista">               -> grade; o 1º <article> dentro dela serve de molde
//   data-campo="titulo|resumo|imagem|link|rotulo|data"  -> onde cada informação entra
//
// Se a API não responder (ex.: arquivo aberto direto, sem o backend rodando),
// a página continua mostrando o conteúdo de exemplo que já está no HTML.
(function () {
    'use strict';

    // Endereço da API. Ordem de prioridade:
    //   1) <meta name="api-base" content="https://minha-api.com"> na página;
    //   2) aberto como arquivo ou pelo Live Server (porta 5500) -> backend local na porta 8000;
    //   3) caso contrário, a própria origem (o site está sendo servido pelo backend).
    function enderecoApi() {
        var meta = document.querySelector('meta[name="api-base"]');
        if (meta && meta.content) return meta.content.replace(/\/$/, '');
        if (location.protocol === 'file:' || location.port === '5500' || location.port === '5501') {
            return 'http://localhost:8000';
        }
        return '';
    }

    var API = enderecoApi();
    var TEMPO_LIMITE_MS = 6000;

    function buscarPosts(categoria, inicio, limite) {
        var params = new URLSearchParams({ inicio: inicio, limite: limite });
        if (categoria) params.set('categoria', categoria);

        var controle = new AbortController();
        var timer = setTimeout(function () { controle.abort(); }, TEMPO_LIMITE_MS);

        return fetch(API + '/api/posts?' + params.toString(), { signal: controle.signal })
            .then(function (resp) {
                if (!resp.ok) throw new Error('API respondeu ' + resp.status);
                return resp.json();
            })
            .finally(function () { clearTimeout(timer); });
    }

    // ---------- Formatação ----------

    function dataRelativa(iso) {
        if (!iso) return '';
        var data = new Date(iso);
        if (isNaN(data)) return '';
        var agora = new Date();
        var min = Math.round((agora - data) / 60000);
        var hora = data.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

        if (min < 1) return 'Agora há pouco';
        if (min < 60) return 'Há ' + min + (min === 1 ? ' minuto' : ' minutos');
        var ontem = new Date(agora); ontem.setDate(agora.getDate() - 1);
        if (data.toDateString() === agora.toDateString()) {
            var h = Math.floor(min / 60);
            return 'Há ' + h + (h === 1 ? ' hora' : ' horas');
        }
        if (data.toDateString() === ontem.toDateString()) return 'Ontem, ' + hora;
        return data.toLocaleDateString('pt-BR') + ', ' + hora;
    }

    // Só aceita links http(s) ou relativos; bloqueia "javascript:" e afins.
    function linkSeguro(url) {
        if (!url) return '#';
        try {
            var u = new URL(url, location.href);
            return (u.protocol === 'http:' || u.protocol === 'https:' || u.protocol === 'file:') ? url : '#';
        } catch (e) {
            return '#';
        }
    }

    function ehExterno(url) {
        try { return new URL(url, location.href).origin !== location.origin; } catch (e) { return false; }
    }

    function imagemReserva(post) {
        var texto = encodeURIComponent(post.categoria || 'Notícia');
        return 'https://placehold.co/800x450/0B1A31/FBF7F7?text=' + texto;
    }

    // Na home, cada etiqueta ganha a cor da sua editoria (mesmas cores do HTML original).
    var CORES = {
        'esportes': 'orange', 'economia': 'emerald', 'politica': 'red', 'brasil': 'green',
        'mundo': 'cyan', 'saude': 'teal', 'tecnologia': 'indigo', 'entretenimento': 'pink'
    };

    function semAcento(texto) {
        return (texto || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
    }

    function pintarRotulo(el, categoria) {
        var cor = CORES[semAcento(categoria)];
        if (!cor) return;
        Array.from(el.classList).forEach(function (cls) {
            var m = cls.match(/^(text|bg)-[a-z]+-600$/);
            if (m) el.classList.replace(cls, m[1] + '-' + cor + '-600');
        });
    }

    // ---------- Preenchimento ----------

    // textContent (e não innerHTML) garante que um título com "<script>" apareça como texto.
    function preencher(elemento, post, usarFonteNoRotulo) {
        elemento.querySelectorAll('[data-campo]').forEach(function (el) {
            switch (el.getAttribute('data-campo')) {
                case 'titulo':
                    el.textContent = post.titulo;
                    break;
                case 'resumo':
                    el.textContent = post.resumo || '';
                    el.hidden = !post.resumo;
                    break;
                case 'rotulo':
                    el.textContent = usarFonteNoRotulo ? (post.fonte || post.categoria) : post.categoria;
                    if (!usarFonteNoRotulo) pintarRotulo(el, post.categoria);
                    break;
                case 'data':
                    el.textContent = dataRelativa(post.data_publicacao);
                    if (post.data_publicacao) el.title = new Date(post.data_publicacao).toLocaleString('pt-BR');
                    break;
                case 'imagem':
                    el.removeAttribute('onerror');
                    el.onerror = function () { el.onerror = null; el.src = imagemReserva(post); };
                    el.src = post.imagem ? linkSeguro(post.imagem) : imagemReserva(post);
                    el.alt = post.titulo;
                    break;
                case 'link':
                    el.href = linkSeguro(post.url);
                    if (ehExterno(post.url)) {
                        el.target = '_blank';
                        el.rel = 'noopener noreferrer';
                    } else {
                        el.removeAttribute('target');
                    }
                    break;
            }
        });
    }

    function mensagemVazia(texto) {
        var p = document.createElement('p');
        p.className = 'text-gray-500 text-center py-16 bg-white rounded-lg border border-gray-100';
        p.textContent = texto;
        return p;
    }

    function botaoVerMais() {
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'block mx-auto self-center mt-8 px-6 py-3 rounded-md font-semibold border border-gray-300 bg-white text-gray-800 hover:border-blue-600 hover:text-blue-600 disabled:opacity-50';
        btn.textContent = 'Ver mais notícias';
        return btn;
    }

    function iniciar() {
        var main = document.querySelector('main');
        var destaque = document.querySelector('[data-noticia="destaque"]');
        var lista = document.querySelector('[data-noticias="lista"]');
        if (!main || (!destaque && !lista)) return;

        var categoria = main.getAttribute('data-categoria') || null;
        var usarFonte = !!categoria; // na página da categoria, o rótulo mostra a fonte
        var molde = lista ? lista.querySelector('article') : null;
        var porPagina = lista ? lista.querySelectorAll('article').length : 0;
        var limiteInicial = (destaque ? 1 : 0) + porPagina;
        var carregados = 0;

        function liberar() { document.documentElement.classList.remove('carregando-noticias'); }

        function adicionarCards(posts) {
            posts.forEach(function (post) {
                var card = molde.cloneNode(true);
                preencher(card, post, usarFonte);
                lista.appendChild(card);
            });
        }

        buscarPosts(categoria, 0, limiteInicial)
            .then(function (dados) {
                var posts = dados.itens || [];
                carregados = posts.length;

                if (posts.length === 0) {
                    var aviso = mensagemVazia(categoria
                        ? 'Ainda não há notícias publicadas em ' + categoria + '.'
                        : 'Ainda não há notícias publicadas.');
                    (destaque || lista).replaceWith(aviso);
                    if (destaque && lista) lista.remove();
                    return;
                }

                if (destaque) preencher(destaque, posts.shift(), usarFonte);

                if (lista && molde) {
                    lista.innerHTML = '';
                    adicionarCards(posts);
                    if (posts.length === 0) lista.hidden = true;

                    if (carregados < dados.total) {
                        var btn = botaoVerMais();
                        lista.insertAdjacentElement('afterend', btn);
                        btn.addEventListener('click', function () {
                            btn.disabled = true;
                            btn.textContent = 'Carregando...';
                            buscarPosts(categoria, carregados, Math.max(porPagina, 3) * 2)
                                .then(function (mais) {
                                    lista.hidden = false;
                                    adicionarCards(mais.itens);
                                    carregados += mais.itens.length;
                                    if (carregados >= mais.total || mais.itens.length === 0) {
                                        btn.remove();
                                    } else {
                                        btn.disabled = false;
                                        btn.textContent = 'Ver mais notícias';
                                    }
                                })
                                .catch(function () {
                                    btn.disabled = false;
                                    btn.textContent = 'Tentar de novo';
                                });
                        });
                    }
                }
            })
            .catch(function (erro) {
                console.warn('[noticias] API indisponível, mostrando o conteúdo de exemplo do HTML.', erro);
            })
            .finally(liberar);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', iniciar);
    } else {
        iniciar();
    }
})();
