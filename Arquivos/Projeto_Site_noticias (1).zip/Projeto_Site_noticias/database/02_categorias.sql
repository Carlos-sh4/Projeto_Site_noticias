﻿USE SiteNoticias
GO

-- Categorias com os mesmos nomes das paginas do menu do site.
-- O site procura sem diferenciar acento nem maiuscula ("Politica" tambem funciona),
-- mas o nome aparece nas etiquetas como estiver gravado aqui.
-- Pode rodar mais de uma vez: so insere o que ainda nao existe.
INSERT INTO Categorias (NomeCategoria, DescricaoCategoria)
SELECT
v.NomeCategoria
, v.DescricaoCategoria
FROM (VALUES
('Esportes', 'Futebol, campeonatos e outros esportes')
, ('Economia', 'Mercado, juros, emprego e financas pessoais')
, ('Política', 'Congresso, governo e eleicoes')
, ('Brasil', 'Noticias de todas as regioes do pais')
, ('Mundo', 'Noticias internacionais')
, ('Saúde', 'Saude publica, prevencao e bem-estar')
, ('Tecnologia', 'Noticias sobre tecnologia, software e inovacao')
, ('Entretenimento', 'Series, filmes, musica e games')
) v (NomeCategoria, DescricaoCategoria)
WHERE NOT EXISTS (SELECT 1 FROM Categorias c WHERE c.NomeCategoria COLLATE Latin1_General_CI_AI = v.NomeCategoria);

SELECT
ID_Categoria
, NomeCategoria
, DescricaoCategoria
FROM Categorias
ORDER BY NomeCategoria;
