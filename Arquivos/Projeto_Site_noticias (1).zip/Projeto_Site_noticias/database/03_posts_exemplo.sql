﻿USE SiteNoticias
GO

-- Noticias de EXEMPLO (as mesmas que estavam escritas no HTML), so para ver o site
-- funcionando com o banco. Rode depois do 02_categorias.sql.
-- As datas sao relativas ao momento da carga, entao o site mostra "Ha 2 horas" etc.
-- Pode rodar mais de uma vez: a URL_Post e unica e evita duplicar.
-- Para apagar so os exemplos depois:  DELETE FROM Posts WHERE URL_Post LIKE '%#exemplo-%';
INSERT INTO Posts (Titulo_Post, Resumo, URL_Post, URL_Imagem, Fonte, ID_Categoria, DataPublicacao)
SELECT
v.Titulo
, v.Resumo
, v.URL
, v.Imagem
, 'Redação'
, c.ID_Categoria
, DATEADD(MINUTE, -v.MinutosAtras, SYSDATETIME())
FROM (VALUES
('Estácio Arapiraca: turma de Banco de Dados desenvolve portal de notícias', 'Alunos da turma de Banco de Dados da faculdade Estácio estão desenvolvendo um projeto muito interessante.', 'tecnologia.html#exemplo-estacio', 'img/foto 01.jpeg', 'Tecnologia', 120)
, ('Análise detalhada do processador AMD Ryzen 7 7735HS mobile', NULL, 'tecnologia.html#exemplo-ryzen', NULL, 'Tecnologia', 1500)
, ('Comunidade maker cria dispositivos multifuncionais usando ESP32', NULL, 'tecnologia.html#exemplo-esp32', NULL, 'Tecnologia', 2900)
, ('Como manipular arquivos CSV no navegador com Papa Parse e SheetJS', NULL, 'tecnologia.html#exemplo-csv', NULL, 'Tecnologia', 4300)

, ('5 coisas que pacientes fazem e irritam profissionais de saúde', 'Entrevista a profissionais da área mostra que alguns comportamentos dos pacientes os deixam irritados.', 'saude.html#exemplo-pacientes', 'img/foto 03.jpg', 'Saúde', 300)
, ('Agentes comunitários recebem novos dashboards interativos para o e-SUS', 'Painéis permitem filtrar microáreas e acompanhar relatórios em tempo real.', 'saude.html#exemplo-esus', NULL, 'Saúde', 1600)
, ('Sistema alerta quando temperatura da câmara fria sai da faixa de 2°C a 8°C', NULL, 'saude.html#exemplo-camara-fria', NULL, 'Saúde', 3000)
, ('Uso do protocolo IVCF-20 agiliza o atendimento de idosos', NULL, 'saude.html#exemplo-ivcf', NULL, 'Saúde', 4400)

, ('Em breve novo site com notícias sobre economia estará no ar', 'O site vem cheio de informações que ajudam a população a decidir sobre sua vida financeira.', 'economia.html#exemplo-novo-site', 'img/foto 05.jpg', 'Economia', 1335)
, ('Banco Central define novos rumos para a taxa Selic nesta quarta-feira', 'Especialistas projetam impactos diretos nos financiamentos e na poupança após a reunião do Copom.', 'economia.html#exemplo-selic', NULL, 'Economia', 400)
, ('Ibovespa fecha em alta impulsionado por setor de commodities', NULL, 'economia.html#exemplo-ibovespa', NULL, 'Economia', 1700)
, ('Geração de empregos formais supera expectativas no trimestre', NULL, 'economia.html#exemplo-empregos', NULL, 'Economia', 3100)

, ('Flamengo abre vantagem sobre o segundo colocado no Brasileirão', 'Com a vitória deste domingo sobre o Bragantino, o Flamengo se isola na liderança. Veja os detalhes da partida.', 'esportes.html#exemplo-flamengo', 'img/foto 04.jpg', 'Esportes', 1540)
, ('Real Madrid vira nos acréscimos e vai à semifinal da Champions', 'Em uma noite mágica no Bernabéu, a equipe merengue mostra mais uma vez o peso da sua camisa no cenário europeu.', 'esportes.html#exemplo-champions', NULL, 'Esportes', 500)
, ('Armador quebra o recorde de bolas de três em um único jogo', 'Atleta acertou 16 bolas de longa distância na noite passada.', 'esportes.html#exemplo-basquete', NULL, 'Esportes', 1800)

, ('Senado aprova pacote de medidas de transparência para gastos públicos', 'O texto segue para sanção e estabelece novas regras para portais de transparência de municípios.', 'politica.html#exemplo-transparencia', NULL, 'Política', 200)
, ('Acordo comercial bilateral será assinado na próxima cúpula', NULL, 'politica.html#exemplo-acordo', NULL, 'Política', 1400)
, ('Tribunal Superior define regras contra o uso de deepfakes em campanhas', NULL, 'politica.html#exemplo-deepfakes', NULL, 'Política', 2800)
, ('Prefeitos pressionam por novo repasse do Fundo de Participação', NULL, 'politica.html#exemplo-fpm', NULL, 'Política', 4200)

, ('Praias de Pajuçara, em Maceió, batem recorde de turistas na alta temporada', 'Bairro litorâneo atrai visitantes com passeios às piscinas naturais e orla revitalizada.', 'brasil.html#exemplo-pajucara', NULL, 'Brasil', 250)
, ('Governo anuncia pacote de modernização de portos', NULL, 'brasil.html#exemplo-portos', NULL, 'Brasil', 1450)
, ('Seca prolongada afeta produção agrícola no Centro-Oeste', NULL, 'brasil.html#exemplo-seca', NULL, 'Brasil', 2850)
, ('MEC abre inscrições para novos programas de bolsas de estudo', NULL, 'brasil.html#exemplo-bolsas', NULL, 'Brasil', 4250)

, ('Líderes mundiais se reúnem em cúpula para debater segurança global', 'Encontro reúne representantes de mais de 50 países para tratar de cooperação econômica e ambiental.', 'mundo.html#exemplo-cupula', NULL, 'Mundo', 350)
, ('Bloco europeu aprova novas regras para regulação de inteligência artificial', NULL, 'mundo.html#exemplo-ia', NULL, 'Mundo', 1550)
, ('Bancos centrais discutem coordenação de juros para conter inflação', NULL, 'mundo.html#exemplo-juros', NULL, 'Mundo', 2950)
, ('Relatório aponta recorde de temperatura média nos oceanos', NULL, 'mundo.html#exemplo-oceanos', NULL, 'Mundo', 4350)

, ('Séries mais aguardadas do ano ganham data de estreia; veja o calendário', 'Plataformas anunciam suas principais apostas para a temporada de premiações.', 'entretenimento.html#exemplo-series', NULL, 'Entretenimento', 450)
, ('Estúdios indies roubam a cena na principal feira de games do ano', NULL, 'entretenimento.html#exemplo-indies', NULL, 'Entretenimento', 1650)
, ('Retorno do vinil: vendas superam CDs pela primeira vez na década', NULL, 'entretenimento.html#exemplo-vinil', NULL, 'Entretenimento', 3050)
, ('Como instalar e usar o JDownloader 2 pelo Prompt de Comando', NULL, 'entretenimento.html#exemplo-jdownloader', NULL, 'Entretenimento', 4450)
) v (Titulo, Resumo, URL, Imagem, Categoria, MinutosAtras)
JOIN Categorias c ON c.NomeCategoria COLLATE Latin1_General_CI_AI = v.Categoria
WHERE NOT EXISTS (SELECT 1 FROM Posts p WHERE p.URL_Post = v.URL);

SELECT
c.NomeCategoria
, COUNT(p.ID_Post) AS TotalPosts
FROM Categorias c
LEFT JOIN Posts p ON p.ID_Categoria = c.ID_Categoria
GROUP BY c.NomeCategoria
ORDER BY c.NomeCategoria;
