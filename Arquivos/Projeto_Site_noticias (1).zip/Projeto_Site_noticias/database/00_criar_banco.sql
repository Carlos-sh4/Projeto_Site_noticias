﻿-- Cria o banco do site, se ainda nao existir.
-- Se o time escolher outro nome, troque "SiteNoticias" aqui, nos scripts 01 a 03
-- e na variavel DB_NAME do arquivo backend/.env.
IF DB_ID('SiteNoticias') IS NULL
CREATE DATABASE SiteNoticias;
GO
