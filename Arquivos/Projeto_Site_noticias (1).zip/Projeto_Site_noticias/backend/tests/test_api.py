"""Testes da API sem precisar de SQL Server: o repositorio e trocado por um falso.

Rodar (dentro da pasta backend):  python -m pytest
"""
import sqlglot
from fastapi.testclient import TestClient

from app import repositorio as r
from app.db import BancoIndisponivel
from app.main import app, obter_repositorio

POSTS = [
    {"id": 3, "titulo": "Terceiro", "resumo": "R3", "url": "https://exemplo.com/3", "imagem": None,
     "fonte": "G1", "categoria": "Economia", "autor": None, "data_publicacao": "2026-10-06T10:00:00"},
    {"id": 2, "titulo": "Segundo", "resumo": None, "url": "https://exemplo.com/2", "imagem": None,
     "fonte": None, "categoria": "Política", "autor": "wjunior", "data_publicacao": "2026-10-05T10:00:00"},
    {"id": 1, "titulo": "Primeiro", "resumo": "R1", "url": "https://exemplo.com/1", "imagem": None,
     "fonte": None, "categoria": "Economia", "autor": None, "data_publicacao": "2026-10-04T10:00:00"},
]


class RepositorioFalso:
    def __init__(self):
        self.chamadas = []

    def listar_categorias(self):
        return [{"id": 1, "nome": "Economia", "descricao": None, "total_posts": 2}]

    def listar_posts(self, categoria, inicio, limite):
        self.chamadas.append((categoria, inicio, limite))
        itens = [p for p in POSTS if categoria is None or p["categoria"].lower() == categoria.lower()]
        return {"itens": itens[inicio:inicio + limite], "inicio": inicio, "limite": limite, "total": len(itens)}

    def obter_post(self, id_post):
        return next((p for p in POSTS if p["id"] == id_post), None)


class RepositorioQuebrado:
    def listar_posts(self, *a):
        raise BancoIndisponivel("login failed")


falso = RepositorioFalso()
app.dependency_overrides[obter_repositorio] = lambda: falso
cliente = TestClient(app)


def test_lista_posts_paginada():
    resp = cliente.get("/api/posts", params={"limite": 2})
    assert resp.status_code == 200
    corpo = resp.json()
    assert [p["id"] for p in corpo["itens"]] == [3, 2]
    assert corpo["total"] == 3

    resp = cliente.get("/api/posts", params={"limite": 2, "inicio": 2})
    assert [p["id"] for p in resp.json()["itens"]] == [1]


def test_filtra_por_categoria():
    resp = cliente.get("/api/posts", params={"categoria": " economia "})
    assert [p["id"] for p in resp.json()["itens"]] == [3, 1]
    assert falso.chamadas[-1][0] == "economia"  # espacos removidos


def test_valida_parametros():
    assert cliente.get("/api/posts", params={"limite": 0}).status_code == 422
    assert cliente.get("/api/posts", params={"limite": 51}).status_code == 422
    assert cliente.get("/api/posts", params={"inicio": -1}).status_code == 422


def test_post_por_id():
    assert cliente.get("/api/posts/2").json()["titulo"] == "Segundo"
    assert cliente.get("/api/posts/999").status_code == 404


def test_categorias():
    assert cliente.get("/api/categorias").json()[0]["nome"] == "Economia"


def test_banco_fora_do_ar_responde_503_sem_detalhe_tecnico():
    app.dependency_overrides[obter_repositorio] = lambda: RepositorioQuebrado()
    try:
        resp = cliente.get("/api/posts")
        assert resp.status_code == 503
        assert "login" not in resp.text
    finally:
        app.dependency_overrides[obter_repositorio] = lambda: falso


def test_site_e_servido_pelo_backend():
    resp = cliente.get("/")
    assert resp.status_code == 200
    assert "<html" in resp.text.lower()
    assert cliente.get("/js/noticias.js").status_code == 200


def _tsql_valido(sql):
    # sqlglot nao entende "?", entao troca por um valor qualquer so para checar a sintaxe
    sqlglot.parse_one(sql.replace("?", "1"), read="tsql")


def test_sql_e_tsql_valido():
    filtro = "WHERE " + r.FILTRO_CATEGORIA + "\n"
    for sql in [
        r.SQL_CATEGORIAS,
        r.SQL_POST_POR_ID,
        r.SQL_POSTS_TOTAL,
        r.SQL_POSTS_TOTAL + filtro,
        r.SQL_POSTS_COLUNAS + r.SQL_POSTS_ORDEM,
        r.SQL_POSTS_COLUNAS + filtro + r.SQL_POSTS_ORDEM,
    ]:
        _tsql_valido(sql)


class CursorFalso:
    def __init__(self, resultados):
        self.resultados = resultados
        self.executados = []

    def execute(self, sql, *params):
        self.executados.append((sql, params))

    def fetchall(self):
        return self.resultados.pop(0)


class ConexaoFalsa:
    def __init__(self, resultados):
        self.c = CursorFalso(resultados)

    def cursor(self):
        return self.c


def test_repositorio_monta_consulta_parametrizada(monkeypatch):
    import sys
    import types

    # pyodbc pode nao estar instalado com driver no ambiente de teste
    monkeypatch.setitem(sys.modules, "pyodbc", types.SimpleNamespace(Error=Exception))
    from datetime import datetime

    linha = (7, "T", None, "u", None, None, "Economia", None, datetime(2026, 10, 6, 9, 30))
    conexao = ConexaoFalsa([[(1,)], [linha]])
    res = r.Repositorio(conexao).listar_posts("Economia'; DROP TABLE Posts--", 0, 4)

    (sql_total, p_total), (sql_lista, p_lista) = conexao.c.executados
    assert "DROP" not in sql_total and "DROP" not in sql_lista  # valor vai como parametro
    assert p_total == ("Economia'; DROP TABLE Posts--",)
    assert p_lista == ("Economia'; DROP TABLE Posts--", 0, 4)
    assert res["itens"][0]["data_publicacao"] == "2026-10-06T09:30:00"
