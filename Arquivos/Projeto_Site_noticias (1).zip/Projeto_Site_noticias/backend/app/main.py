"""API do portal de noticias.

Rodar (dentro da pasta backend):  uvicorn app.main:app --reload
Site:  http://localhost:8000      Documentacao da API:  http://localhost:8000/docs
"""
import logging

from fastapi import Depends, FastAPI, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from .config import PASTA_FRONTEND, origens_cors
from .db import BancoIndisponivel, obter_conexao
from .repositorio import Repositorio

log = logging.getLogger("site_noticias")

app = FastAPI(
    title="API - Portal de Notícias",
    description="Lê as notícias do SQL Server e entrega para o site.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=origens_cors(),
    allow_methods=["GET"],
    allow_headers=["*"],
)


@app.exception_handler(BancoIndisponivel)
async def banco_indisponivel(request: Request, erro: BancoIndisponivel):
    # O detalhe tecnico vai para o terminal; o navegador recebe so uma mensagem simples.
    log.error("Falha no banco de dados: %s", erro)
    return JSONResponse(status_code=503, content={"erro": "Banco de dados indisponível"})


def obter_repositorio(conexao=Depends(obter_conexao)) -> Repositorio:
    return Repositorio(conexao)


@app.get("/api/saude", tags=["Diagnóstico"])
def saude():
    """Confere se a API está no ar e se consegue falar com o banco."""
    from .db import conectar

    try:
        conexao = conectar()
        conexao.cursor().execute("SELECT 1").fetchone()
        conexao.close()
        return {"api": "ok", "banco": "ok"}
    except BancoIndisponivel as erro:
        log.error("Teste de conexao falhou: %s", erro)
        return JSONResponse(status_code=503, content={"api": "ok", "banco": "erro"})


@app.get("/api/categorias", tags=["Notícias"])
def listar_categorias(repo: Repositorio = Depends(obter_repositorio)):
    return repo.listar_categorias()


@app.get("/api/posts", tags=["Notícias"])
def listar_posts(
    categoria: str | None = Query(None, max_length=50, description="Nome da categoria, ex.: Economia"),
    inicio: int = Query(0, ge=0, description="Quantos posts pular (para paginação)"),
    limite: int = Query(10, ge=1, le=50, description="Quantos posts trazer"),
    repo: Repositorio = Depends(obter_repositorio),
):
    """Notícias mais recentes primeiro. Sem categoria, traz de todas."""
    return repo.listar_posts(categoria.strip() if categoria else None, inicio, limite)


@app.get("/api/posts/{id_post}", tags=["Notícias"])
def obter_post(id_post: int, repo: Repositorio = Depends(obter_repositorio)):
    post = repo.obter_post(id_post)
    if post is None:
        raise HTTPException(status_code=404, detail="Notícia não encontrada")
    return post


# O proprio backend entrega as paginas do site. Fica por ultimo para nao
# "engolir" as rotas /api acima.
if PASTA_FRONTEND.is_dir():
    app.mount("/", StaticFiles(directory=PASTA_FRONTEND, html=True), name="site")
