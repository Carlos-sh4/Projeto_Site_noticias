"""Conexao com o SQL Server via pyodbc."""
from collections.abc import Iterator

from .config import string_de_conexao


class BancoIndisponivel(Exception):
    """Nao foi possivel conectar ou consultar o SQL Server."""


def conectar():
    # Import aqui dentro para os testes rodarem sem o driver ODBC instalado.
    import pyodbc

    try:
        return pyodbc.connect(string_de_conexao(), timeout=5, autocommit=True)
    except pyodbc.Error as erro:
        raise BancoIndisponivel(str(erro)) from erro


def obter_conexao() -> Iterator:
    """Dependencia do FastAPI: abre uma conexao por requisicao e fecha no final."""
    conexao = conectar()
    try:
        yield conexao
    finally:
        conexao.close()
