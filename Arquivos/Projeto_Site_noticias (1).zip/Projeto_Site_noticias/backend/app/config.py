"""Configuracao lida das variaveis de ambiente (arquivo backend/.env)."""
import os
from pathlib import Path

from dotenv import load_dotenv

PASTA_BACKEND = Path(__file__).resolve().parents[1]
PASTA_FRONTEND = PASTA_BACKEND.parent / "frontend"

load_dotenv(PASTA_BACKEND / ".env")


def _sim(valor: str | None) -> bool:
    return (valor or "").strip().lower() in {"1", "sim", "s", "true", "yes", "y"}


def string_de_conexao() -> str:
    """Monta a string ODBC a partir do .env (ou usa DB_CONNECTION_STRING pronta)."""
    pronta = os.getenv("DB_CONNECTION_STRING", "").strip()
    if pronta:
        return pronta

    partes = [
        f"DRIVER={{{os.getenv('DB_DRIVER', 'ODBC Driver 17 for SQL Server')}}}",
        f"SERVER={os.getenv('DB_SERVER', 'localhost')}",
        f"DATABASE={os.getenv('DB_NAME', 'SiteNoticias')}",
    ]
    if _sim(os.getenv("DB_TRUSTED", "sim")):
        partes.append("Trusted_Connection=yes")
    else:
        partes.append(f"UID={os.getenv('DB_USER', '')}")
        partes.append(f"PWD={os.getenv('DB_PASSWORD', '')}")
    if _sim(os.getenv("DB_TRUST_CERT", "sim")):
        partes.append("TrustServerCertificate=yes")
    return ";".join(partes)


def origens_cors() -> list[str]:
    bruto = os.getenv("CORS_ORIGENS", "http://127.0.0.1:5500,http://localhost:5500")
    return [o.strip() for o in bruto.split(",") if o.strip()]
