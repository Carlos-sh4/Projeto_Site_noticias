"""Consultas ao banco. Todo valor vindo do usuario entra como parametro (?),
nunca concatenado no texto do SQL, para evitar SQL injection."""
from datetime import datetime

from .db import BancoIndisponivel

# Comparacao sem diferenciar maiusculas nem acentos: "politica" encontra "Política".
FILTRO_CATEGORIA = "c.NomeCategoria COLLATE Latin1_General_CI_AI = ?"

SQL_CATEGORIAS = """
SELECT
c.ID_Categoria
, c.NomeCategoria
, c.DescricaoCategoria
, COUNT(p.ID_Post) AS TotalPosts
FROM Categorias c
LEFT JOIN Posts p ON p.ID_Categoria = c.ID_Categoria
GROUP BY c.ID_Categoria, c.NomeCategoria, c.DescricaoCategoria
ORDER BY c.NomeCategoria
"""

SQL_POSTS_COLUNAS = """
SELECT
p.ID_Post
, p.Titulo_Post
, p.Resumo
, p.URL_Post
, p.URL_Imagem
, p.Fonte
, c.NomeCategoria
, u.NomeUsuario
, p.DataPublicacao
FROM Posts p
JOIN Categorias c ON c.ID_Categoria = p.ID_Categoria
LEFT JOIN Usuario u ON u.ID_Usuario = p.ID_Autor
"""

SQL_POSTS_ORDEM = """
ORDER BY p.DataPublicacao DESC, p.ID_Post DESC
OFFSET ? ROWS FETCH NEXT ? ROWS ONLY
"""

SQL_POSTS_TOTAL = """
SELECT
COUNT(*)
FROM Posts p
JOIN Categorias c ON c.ID_Categoria = p.ID_Categoria
"""

SQL_POST_POR_ID = SQL_POSTS_COLUNAS + "WHERE p.ID_Post = ?\n"


def _data_iso(valor) -> str | None:
    if isinstance(valor, datetime):
        return valor.isoformat(timespec="seconds")
    return str(valor) if valor is not None else None


def _post(linha) -> dict:
    return {
        "id": linha[0],
        "titulo": linha[1],
        "resumo": linha[2],
        "url": linha[3],
        "imagem": linha[4],
        "fonte": linha[5],
        "categoria": linha[6],
        "autor": linha[7],
        "data_publicacao": _data_iso(linha[8]),
    }


class Repositorio:
    def __init__(self, conexao):
        self.conexao = conexao

    def _consultar(self, sql: str, *parametros) -> list:
        import pyodbc

        try:
            cursor = self.conexao.cursor()
            cursor.execute(sql, *parametros)
            return cursor.fetchall()
        except pyodbc.Error as erro:
            raise BancoIndisponivel(str(erro)) from erro

    def listar_categorias(self) -> list[dict]:
        return [
            {"id": l[0], "nome": l[1], "descricao": l[2], "total_posts": l[3]}
            for l in self._consultar(SQL_CATEGORIAS)
        ]

    def listar_posts(self, categoria: str | None, inicio: int, limite: int) -> dict:
        if categoria:
            filtro = "WHERE " + FILTRO_CATEGORIA + "\n"
            parametros_filtro = [categoria]
        else:
            filtro = ""
            parametros_filtro = []

        total = self._consultar(SQL_POSTS_TOTAL + filtro, *parametros_filtro)[0][0]
        linhas = self._consultar(
            SQL_POSTS_COLUNAS + filtro + SQL_POSTS_ORDEM,
            *parametros_filtro, inicio, limite,
        )
        return {
            "itens": [_post(l) for l in linhas],
            "inicio": inicio,
            "limite": limite,
            "total": total,
        }

    def obter_post(self, id_post: int) -> dict | None:
        linhas = self._consultar(SQL_POST_POR_ID, id_post)
        return _post(linhas[0]) if linhas else None
