"""Testes do coletor sem internet e sem SQL Server.  Rodar:  python -m pytest  (na pasta coletor)"""
import io
import json
import urllib.error
from datetime import datetime, timedelta, timezone

import pytest
import sqlglot

import coletor as c


ARTIGO = {
    "title": "  Seleção   vence\n amistoso ",
    "description": "x" * 1200,
    "url": "https://exemplo.com.br/selecao",
    "image": "https://exemplo.com.br/foto.jpg",
    "source": {"name": "Agência Exemplo"},
    "publishedAt": "2026-10-06T12:00:00Z",
}


def test_monta_url_por_categoria():
    url = c.montar_url("Esportes", "CHAVE")
    assert url.startswith("https://gnews.io/api/v4/top-headlines?")
    assert "category=sports" in url and "lang=pt" in url and "country=br" in url and "apikey=CHAVE" in url
    url = c.montar_url("Política", "CHAVE")
    assert "/search?" in url and "q=pol%C3%ADtica" in url


def test_todas_as_categorias_do_site_tem_regra():
    assert set(c.CATEGORIAS) == {"Esportes", "Economia", "Política", "Brasil", "Mundo", "Saúde", "Tecnologia", "Entretenimento"}


def test_converte_e_respeita_tamanho_das_colunas():
    post = c.converter_artigo(ARTIGO, "Esportes")
    assert post["titulo"] == "Seleção vence amistoso"
    assert len(post["resumo"]) == c.MAX_RESUMO and post["resumo"].endswith("…")
    assert post["fonte"] == "Agência Exemplo"
    esperado = datetime(2026, 10, 6, 12, tzinfo=timezone.utc).astimezone().replace(tzinfo=None)
    assert post["data_publicacao"] == esperado


def test_descarta_artigo_sem_titulo_ou_link_invalido():
    assert c.converter_artigo({**ARTIGO, "title": ""}, "Mundo") is None
    assert c.converter_artigo({**ARTIGO, "url": "javascript:alert(1)"}, "Mundo") is None
    assert c.converter_artigo({**ARTIGO, "url": "https://x.com/" + "a" * 900}, "Mundo") is None
    assert c.converter_artigo({**ARTIGO, "image": "ftp://x"}, "Mundo")["imagem"] is None


def test_proxima_execucao():
    agora = datetime(2026, 10, 6, 8, 0)
    assert c.proxima_execucao("07:00", agora) == datetime(2026, 10, 7, 7, 0)
    assert c.proxima_execucao("09:30", agora) == datetime(2026, 10, 6, 9, 30)


def test_sql_e_tsql_valido():
    sqlglot.parse_one(c.SQL_INSERIR.replace("?", "1"), read="tsql")
    sqlglot.parse_one(c.SQL_CATEGORIAS, read="tsql")


# ---- coleta completa com API e banco falsos

class CursorFalso:
    def __init__(self, banco):
        self.banco = banco
        self.rowcount = 0

    def execute(self, sql, *params):
        if "INSERT" in sql:
            url = params[2]
            self.rowcount = 0 if url in self.banco.urls else 1
            self.banco.urls.add(url)
            self.banco.params.append(params)
        return self

    def fetchall(self):
        return [(n,) for n in self.banco.categorias]


class BancoFalso:
    def __init__(self, categorias):
        self.categorias = categorias
        self.urls = set()
        self.params = []

    def cursor(self):
        return CursorFalso(self)


def resposta(artigos):
    return io.BytesIO(json.dumps({"articles": artigos}).encode())


def test_coleta_grava_novas_e_ignora_repetidas(monkeypatch):
    chamadas = []

    def urlopen_falso(pedido, timeout):
        chamadas.append(pedido.full_url)
        return resposta([ARTIGO, {**ARTIGO, "url": "https://exemplo.com.br/outra"}])

    monkeypatch.setattr(c.urllib.request, "urlopen", urlopen_falso)
    banco = BancoFalso(["Esportes", "Economia"])
    res = c.coletar(["Esportes", "Economia"], "K", conexao=banco, pausa=0)

    assert len(chamadas) == 2
    assert res["Esportes"] == {"recebidas": 2, "novas": 2, "repetidas": 0, "erro": None}
    assert res["Economia"]["novas"] == 0 and res["Economia"]["repetidas"] == 2  # mesmas URLs
    # categoria vai como parametro, nunca dentro do SQL
    assert banco.params[0][6] == "Esportes"


def test_categoria_que_nao_existe_no_banco_e_pulada(monkeypatch):
    monkeypatch.setattr(c.urllib.request, "urlopen", lambda p, timeout: resposta([ARTIGO]))
    res = c.coletar(["Política", "Mundo"], "K", conexao=BancoFalso(["Politica"]), pausa=0)
    assert list(res) == ["Política"]  # acento nao importa; Mundo nao existe e e pulada


def test_limite_diario_para_a_coleta(monkeypatch):
    def erro_429(pedido, timeout):
        raise urllib.error.HTTPError(pedido.full_url, 429, "Too Many", {}, None)

    monkeypatch.setattr(c.urllib.request, "urlopen", erro_429)
    res = c.coletar(["Esportes", "Economia"], "K", conexao=BancoFalso(["Esportes", "Economia"]), pausa=0)
    assert list(res) == ["Esportes"] and "429" in res["Esportes"]["erro"]


def test_chave_invalida_nao_tenta_as_outras(monkeypatch):
    def erro_401(pedido, timeout):
        raise urllib.error.HTTPError(pedido.full_url, 401, "Unauthorized", {}, None)

    monkeypatch.setattr(c.urllib.request, "urlopen", erro_401)
    res = c.coletar(["Esportes", "Economia"], "K", conexao=BancoFalso(["Esportes", "Economia"]), pausa=0)
    assert list(res) == ["Esportes"] and "Chave" in res["Esportes"]["erro"]


def test_falha_de_rede_tenta_de_novo(monkeypatch):
    tentativas = []

    def instavel(pedido, timeout):
        tentativas.append(1)
        if len(tentativas) < 3:
            raise urllib.error.URLError("sem rede")
        return resposta([ARTIGO])

    monkeypatch.setattr(c.urllib.request, "urlopen", instavel)
    monkeypatch.setattr(c.time, "sleep", lambda s: None)
    assert c.baixar_json("https://gnews.io/x")["articles"][0]["url"] == ARTIGO["url"]
    assert len(tentativas) == 3


def test_simulacao_nao_abre_o_banco(monkeypatch):
    monkeypatch.setattr(c.urllib.request, "urlopen", lambda p, timeout: resposta([ARTIGO]))
    monkeypatch.setattr(c, "conectar", lambda: pytest.fail("não deveria conectar"))
    res = c.coletar(["Mundo"], "K", simular=True, pausa=0)
    assert res["Mundo"]["recebidas"] == 1 and res["Mundo"]["novas"] == 0


def test_categorias_na_linha_de_comando():
    assert c.ler_argumentos(["--categorias", "politica, SAUDE"]).categorias == ["Política", "Saúde"]
    with pytest.raises(SystemExit):
        c.ler_argumentos(["--categorias", "Fofoca"])
    with pytest.raises(SystemExit):
        c.ler_argumentos(["--hora", "7h"])


def test_sem_chave_avisa_e_sai(monkeypatch, tmp_path):
    monkeypatch.delenv("GNEWS_API_KEY", raising=False)
    monkeypatch.setattr(c, "carregar_configuracao", lambda: None)
    monkeypatch.setattr(c, "PASTA", tmp_path)
    assert c.main([]) == 2
