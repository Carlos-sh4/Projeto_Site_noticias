"""Coletor de noticias: busca na API da GNews e grava as novas na tabela Posts.

Uso (dentro da pasta coletor, com o Python do venv do backend):
    python coletor.py                    roda uma vez e termina (ideal para o Agendador de Tarefas)
    python coletor.py --simular          busca e mostra o que gravaria, sem tocar no banco
    python coletor.py --loop --hora 07:00   fica rodando e coleta todo dia nesse horario
    python coletor.py --categorias Esportes,Economia   so algumas categorias
"""
import argparse
import json
import logging
import os
import sys
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timedelta
from logging.handlers import RotatingFileHandler
from pathlib import Path

try:
    from dotenv import load_dotenv
except ImportError:  # sem python-dotenv, usa so as variaveis de ambiente do Windows
    load_dotenv = None

PASTA = Path(__file__).resolve().parent
API_GNEWS = "https://gnews.io/api/v4"

# Categoria do site -> como pedir para a GNews.
# A GNews nao tem categoria "politica", entao Politica usa a busca por palavra-chave.
CATEGORIAS = {
    "Esportes": {"endpoint": "top-headlines", "category": "sports"},
    "Economia": {"endpoint": "top-headlines", "category": "business"},
    "Política": {"endpoint": "search", "q": "política OR governo OR Congresso OR Senado"},
    "Brasil": {"endpoint": "top-headlines", "category": "nation"},
    "Mundo": {"endpoint": "top-headlines", "category": "world"},
    "Saúde": {"endpoint": "top-headlines", "category": "health"},
    "Tecnologia": {"endpoint": "top-headlines", "category": "technology"},
    "Entretenimento": {"endpoint": "top-headlines", "category": "entertainment"},
}

# Tamanhos das colunas da tabela Posts
MAX_TITULO, MAX_RESUMO, MAX_URL, MAX_FONTE = 255, 1000, 850, 100

log = logging.getLogger("coletor")


def sem_acento(texto):
    """'Política' -> 'politica' (para comparar nomes de categoria)."""
    return unicodedata.normalize("NFD", texto or "").encode("ascii", "ignore").decode().lower().strip()


class ErroApi(Exception):
    """Falha ao falar com a API de noticias."""


class LimiteDiarioAtingido(ErroApi):
    """A API recusou por excesso de requisicoes (HTTP 429)."""


# ---------------------------------------------------------------- configuracao

def carregar_configuracao():
    # coletor/.env primeiro; o que faltar vem do backend/.env (mesmo banco)
    if load_dotenv:
        load_dotenv(PASTA / ".env")
        load_dotenv(PASTA.parent / "backend" / ".env")


def _sim(valor):
    return (valor or "").strip().lower() in {"1", "sim", "s", "true", "yes", "y"}


def string_de_conexao():
    pronta = os.getenv("DB_CONNECTION_STRING", "").strip()
    if pronta:
        return pronta
    partes = [
        f"DRIVER={{{os.getenv('DB_DRIVER', 'ODBC Driver 17 for SQL Server')}}}",
        f"SERVER={os.getenv('DB_SERVER', 'localhost')}",
        f"DATABASE={os.getenv('DB_NAME', 'SiteNoticias')}",
    ]
    if _sim(os.getenv("DB_TRUSTED", "sim")):
        partes.append("Trusted_Connection=yes")
    else:
        partes.append(f"UID={os.getenv('DB_USER', '')}")
        partes.append(f"PWD={os.getenv('DB_PASSWORD', '')}")
    if _sim(os.getenv("DB_TRUST_CERT", "sim")):
        partes.append("TrustServerCertificate=yes")
    return ";".join(partes)


def configurar_log():
    pasta_logs = PASTA / "logs"
    pasta_logs.mkdir(exist_ok=True)
    formato = logging.Formatter("%(asctime)s %(levelname)s %(message)s", "%Y-%m-%d %H:%M:%S")
    arquivo = RotatingFileHandler(pasta_logs / "coletor.log", maxBytes=1_000_000, backupCount=5, encoding="utf-8")
    arquivo.setFormatter(formato)
    tela = logging.StreamHandler()
    tela.setFormatter(formato)
    log.handlers[:] = [arquivo, tela]
    log.setLevel(logging.INFO)


# ---------------------------------------------------------------- API de noticias

def montar_url(categoria, chave, maximo=10):
    regra = CATEGORIAS[categoria]
    params = {"lang": "pt", "country": "br", "max": maximo, "apikey": chave}
    if regra["endpoint"] == "search":
        params["q"] = regra["q"]
    else:
        params["category"] = regra["category"]
    return f"{API_GNEWS}/{regra['endpoint']}?{urllib.parse.urlencode(params)}"


def baixar_json(url, tentativas=3, espera_inicial=5):
    """GET com novas tentativas em falha de rede ou erro 5xx."""
    for tentativa in range(1, tentativas + 1):
        try:
            pedido = urllib.request.Request(url, headers={"User-Agent": "ColetorPortalNoticias/1.0"})
            with urllib.request.urlopen(pedido, timeout=30) as resposta:
                return json.loads(resposta.read().decode("utf-8"))
        except urllib.error.HTTPError as erro:
            if erro.code == 429:
                raise LimiteDiarioAtingido("A GNews recusou por limite de requisições (HTTP 429).") from erro
            if erro.code in (401, 403):
                raise ErroApi(f"Chave da API recusada (HTTP {erro.code}). Confira GNEWS_API_KEY no .env.") from erro
            if erro.code < 500 or tentativa == tentativas:
                raise ErroApi(f"A GNews respondeu HTTP {erro.code}.") from erro
        except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as erro:
            if tentativa == tentativas:
                raise ErroApi(f"Sem resposta da GNews: {erro}") from erro
        espera = espera_inicial * 2 ** (tentativa - 1)
        log.warning("Falha ao chamar a API (tentativa %d de %d); nova tentativa em %ds", tentativa, tentativas, espera)
        time.sleep(espera)


def _cortar(texto, limite):
    texto = " ".join((texto or "").split())  # tira quebras de linha e espacos repetidos
    if len(texto) <= limite:
        return texto
    return texto[: limite - 1].rstrip() + "…"


def data_local(iso):
    """'2026-10-06T12:00:00Z' (UTC) -> datetime no fuso do computador, sem fuso (como o site le)."""
    try:
        return datetime.fromisoformat(iso.replace("Z", "+00:00")).astimezone().replace(tzinfo=None)
    except (AttributeError, ValueError):
        return datetime.now().replace(microsecond=0)


def converter_artigo(artigo, categoria):
    """Artigo da GNews -> linha da tabela Posts. None se nao der para gravar."""
    titulo = _cortar(artigo.get("title"), MAX_TITULO)
    url = (artigo.get("url") or "").strip()
    if not titulo or not url.startswith(("http://", "https://")) or len(url) > MAX_URL:
        return None
    imagem = (artigo.get("image") or "").strip()
    if not imagem.startswith(("http://", "https://")) or len(imagem) > MAX_URL:
        imagem = None
    return {
        "titulo": titulo,
        "resumo": _cortar(artigo.get("description"), MAX_RESUMO) or None,
        "url": url,
        "imagem": imagem,
        "fonte": _cortar((artigo.get("source") or {}).get("name"), MAX_FONTE) or None,
        "categoria": categoria,
        "data_publicacao": data_local(artigo.get("publishedAt")),
    }


# ---------------------------------------------------------------- banco

# Grava so se a URL ainda nao existe e se nao ha noticia com o mesmo titulo nos
# ultimos 3 dias (a mesma materia costuma aparecer em mais de um site).
SQL_INSERIR = """
INSERT INTO Posts (Titulo_Post, Resumo, URL_Post, URL_Imagem, Fonte, ID_Categoria, DataPublicacao)
SELECT
?
, ?
, ?
, ?
, ?
, c.ID_Categoria
, ?
FROM Categorias c
WHERE c.NomeCategoria COLLATE Latin1_General_CI_AI = ?
AND NOT EXISTS (SELECT 1 FROM Posts p WHERE p.URL_Post = ?)
AND NOT EXISTS (SELECT 1 FROM Posts p WHERE p.Titulo_Post = ? AND p.DataPublicacao >= DATEADD(DAY, -3, ?))
"""

SQL_CATEGORIAS = """
SELECT
NomeCategoria
FROM Categorias
"""


def conectar():
    import pyodbc

    return pyodbc.connect(string_de_conexao(), timeout=10, autocommit=True)


def gravar(conexao, post):
    """True se inseriu; False se ja existia."""
    cursor = conexao.cursor()
    cursor.execute(
        SQL_INSERIR,
        post["titulo"], post["resumo"], post["url"], post["imagem"], post["fonte"],
        post["data_publicacao"], post["categoria"], post["url"], post["titulo"], post["data_publicacao"],
    )
    return cursor.rowcount == 1


def categorias_no_banco(conexao):
    return {sem_acento(l[0]) for l in conexao.cursor().execute(SQL_CATEGORIAS).fetchall()}


# ---------------------------------------------------------------- execucao

def coletar(categorias, chave, simular=False, conexao=None, pausa=1.0):
    """Roda uma coleta. Devolve {categoria: {'recebidas', 'novas', 'repetidas', 'erro'}}."""
    resumo = {}
    if not simular and conexao is None:
        conexao = conectar()

    if conexao is not None:
        existentes = categorias_no_banco(conexao)
        ausentes = [c for c in categorias if sem_acento(c) not in existentes]
        for c in ausentes:
            log.warning("Categoria '%s' não existe na tabela Categorias; rode o database/02_categorias.sql", c)
        categorias = [c for c in categorias if c not in ausentes]

    for i, categoria in enumerate(categorias):
        if i:
            time.sleep(pausa)  # nao dispara tudo de uma vez na API
        r = resumo[categoria] = {"recebidas": 0, "novas": 0, "repetidas": 0, "erro": None}
        try:
            dados = baixar_json(montar_url(categoria, chave))
        except LimiteDiarioAtingido as erro:
            r["erro"] = str(erro)
            log.error("%s Parando por hoje.", erro)
            break
        except ErroApi as erro:
            r["erro"] = str(erro)
            log.error("%s: %s", categoria, erro)
            if "Chave" in str(erro):
                break  # chave errada falha em todas as categorias
            continue

        for artigo in dados.get("articles", []):
            post = converter_artigo(artigo, categoria)
            if post is None:
                continue
            r["recebidas"] += 1
            if simular:
                log.info("[simulação] %s | %s | %s", categoria, post["fonte"], post["titulo"])
                continue
            try:
                if gravar(conexao, post):
                    r["novas"] += 1
                else:
                    r["repetidas"] += 1
            except Exception as erro:  # um artigo ruim nao derruba a coleta toda
                r["repetidas"] += 1
                log.warning("Não gravou '%s': %s", post["titulo"][:60], erro)

        log.info("%s: %d recebidas, %d novas, %d já existiam", categoria, r["recebidas"], r["novas"], r["repetidas"])
    return resumo


def proxima_execucao(hora, agora=None):
    agora = agora or datetime.now()
    h, m = (int(x) for x in hora.split(":"))
    alvo = agora.replace(hour=h, minute=m, second=0, microsecond=0)
    return alvo if alvo > agora else alvo + timedelta(days=1)


def rodar_uma_vez(args, chave):
    inicio = time.monotonic()
    try:
        resumo = coletar(args.categorias, chave, simular=args.simular)
    except Exception as erro:
        log.error("Coleta interrompida: %s", erro)
        return 1
    novas = sum(r["novas"] for r in resumo.values())
    erros = [c for c, r in resumo.items() if r["erro"]]
    log.info("Fim da coleta em %.0fs: %d notícias novas; categorias com erro: %s",
             time.monotonic() - inicio, novas, ", ".join(erros) or "nenhuma")
    return 1 if resumo and len(erros) == len(resumo) else 0


def ler_argumentos(argv=None):
    p = argparse.ArgumentParser(description="Coleta notícias da GNews e grava na tabela Posts.")
    p.add_argument("--simular", action="store_true", help="busca e mostra, sem gravar no banco")
    p.add_argument("--loop", action="store_true", help="fica rodando e coleta uma vez por dia")
    p.add_argument("--hora", default=os.getenv("COLETOR_HORA", "07:00"), help="horário da coleta no modo --loop (HH:MM)")
    p.add_argument("--agora", action="store_true", help="no modo --loop, faz uma coleta logo ao iniciar")
    p.add_argument("--categorias", help="lista separada por vírgula; padrão: todas")
    args = p.parse_args(argv)

    if args.categorias:
        pedidas = [c.strip() for c in args.categorias.split(",") if c.strip()]
        mapa = {sem_acento(c): c for c in CATEGORIAS}
        desconhecidas = [c for c in pedidas if sem_acento(c) not in mapa]
        if desconhecidas:
            p.error(f"categoria desconhecida: {', '.join(desconhecidas)}. Opções: {', '.join(CATEGORIAS)}")
        args.categorias = [mapa[sem_acento(c)] for c in pedidas]
    else:
        args.categorias = list(CATEGORIAS)

    try:
        datetime.strptime(args.hora, "%H:%M")
    except ValueError:
        p.error("--hora precisa estar no formato HH:MM, ex.: 07:00")
    return args


def main(argv=None):
    carregar_configuracao()
    configurar_log()
    args = ler_argumentos(argv)

    chave = os.getenv("GNEWS_API_KEY", "").strip()
    if not chave:
        log.error("Falta a GNEWS_API_KEY. Crie a chave grátis em https://gnews.io e coloque no coletor/.env")
        return 2

    if not args.loop:
        return rodar_uma_vez(args, chave)

    log.info("Modo contínuo: coleta todo dia às %s. Para parar, Ctrl+C.", args.hora)
    if args.agora:
        rodar_uma_vez(args, chave)
    try:
        while True:
            alvo = proxima_execucao(args.hora)
            log.info("Próxima coleta: %s", alvo.strftime("%d/%m/%Y %H:%M"))
            # dorme em pedacos de 1 min: aguenta o PC hibernar e acordar
            while datetime.now() < alvo:
                time.sleep(min(60, max(1, (alvo - datetime.now()).total_seconds())))
            rodar_uma_vez(args, chave)
    except KeyboardInterrupt:
        log.info("Coletor encerrado pelo usuário.")
        return 0


if __name__ == "__main__":
    sys.exit(main())
