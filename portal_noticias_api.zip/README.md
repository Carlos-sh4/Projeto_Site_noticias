# API do Portal de Notícias (FastAPI)

Este projeto é uma API RESTful para gerenciamento e navegação de um Portal de Notícias, desenvolvida em Python com o framework FastAPI.

## 🚀 Como Executar o Projeto

### 1. Requisitos
- Python 3.8 ou superior
- Gerenciador de pacotes `pip`

### 2. Instalação das Dependências
Instale as dependências executando o comando abaixo:
```bash
pip install -r requirements.txt
```

### 3. Executando o Servidor
Para iniciar a aplicação:
```bash
uvicorn main:app --reload
```

A API estará acessível em: `http://127.0.0.1:8000`

### 4. Documentação Interativa
- **Swagger UI:** `http://127.0.0.1:8000/docs`
- **ReDoc:** `http://127.0.0.1:8000/redoc`

## 📋 Categorias Suportadas
- `noticias`
- `esporte`
- `economia`
- `politica`
- `brasil`
- `mundo`
- `saude`
- `tecnologia`
- `entreterimento`
