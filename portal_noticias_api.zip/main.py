from typing import List, Optional
from fastapi import FastAPI, HTTPException, Path, Query
from pydantic import BaseModel, Field

app = FastAPI(
    title="Notícias API",
    description="API RESTful para o Portal de Notícias desenvolvida em Python e FastAPI.",
    version="1.0.0",
)

# --- Modelos de Dados (Schemas) ---

class NoticiaBase(BaseModel):
    titulo: str = Field(..., example="Nova Descoberta Tecnológica Revoluciona o Mercado")
    subtitulo: Optional[str] = Field(None, example="Especialistas apontam avanços significativos no setor.")
    conteudo: str = Field(..., example="Texto completo da notícia com detalhes e informações atualizadas...")
    autor: str = Field(..., example="Redação Notícias")
    imagem_url: Optional[str] = Field(None, example="http://localhost:8000/img/foto01.jpeg")

class NoticiaCriacao(NoticiaBase):
    pass

class Noticia(NoticiaBase):
    id: int
    categoria: str
    data_publicacao: str

    class Config:
        schema_extra = {
            "example": {
                "id": 1,
                "categoria": "tecnologia",
                "titulo": "Nova Descoberta Tecnológica",
                "subtitulo": "Especialistas apontam avanços",
                "conteudo": "Texto completo da notícia...",
                "autor": "Redação Notícias",
                "data_publicacao": "2026-10-06T20:00:00",
                "imagem_url": "http://localhost:8000/img/foto01.jpeg",
            }
        }

class PlanoAssinatura(BaseModel):
    id: int
    nome: str
    preco_mensal: float
    recursos: List[str]

class AssinaturaSolicitacao(BaseModel):
    nome_usuario: str
    email: str
    plano_id: int

class RespostaAssinatura(BaseModel):
    mensagem: str
    status: str
    detalhes: AssinaturaSolicitacao

# --- Base de Dados Simulada em Memória ---

CATEGORIAS_VALIDAS = [
    "noticias",
    "esporte",
    "economia",
    "politica",
    "brasil",
    "mundo",
    "saude",
    "tecnologia",
    "entreterimento",
]

db_noticias: List[dict] = [
    {
        "id": 1,
        "categoria": "tecnologia",
        "titulo": "Avanços em Inteligência Artificial em 2026",
        "subtitulo": "Novos modelos otimizam desenvolvimento de software",
        "conteudo": "O setor de tecnologia continua em rápida expansão...",
        "autor": "Redação Tech",
        "data_publicacao": "2026-10-06T10:00:00",
        "imagem_url": "img/foto 01.jpeg",
    },
    {
        "id": 2,
        "categoria": "esporte",
        "titulo": "Resultados da Rodada do Campeonato",
        "subtitulo": "Confira os destaques dos jogos deste fim de semana",
        "conteudo": "As equipes entraram em campo em busca da liderança...",
        "autor": "Esporte Clube",
        "data_publicacao": "2026-10-06T11:30:00",
        "imagem_url": "img/foto 02.png",
    },
    {
        "id": 3,
        "categoria": "economia",
        "titulo": "Mercado Financeiro e Perspectivas Globais",
        "subtitulo": "Análise das tendências para o último trimestre",
        "conteudo": "Especialistas analisam os impactos da inflação e taxas de juros...",
        "autor": "Análise Econômica",
        "data_publicacao": "2026-10-06T09:15:00",
        "imagem_url": "img/foto 03.jpg",
    },
    {
        "id": 4,
        "categoria": "politica",
        "titulo": "Discussões Sobre Novas Reformas no Congresso",
        "subtitulo": "Propostas entram em pauta na sessão desta semana",
        "conteudo": "Os parlamentares debatem os pontos centrais da nova proposta...",
        "autor": "Cobertura Política",
        "data_publicacao": "2026-10-05T16:00:00",
        "imagem_url": None,
    },
    {
        "id": 5,
        "categoria": "brasil",
        "titulo": "Projetos de Infraestrutura Avançam no País",
        "subtitulo": "Investimentos públicos e privados impulsionam obras",
        "conteudo": "Diversas regiões do Brasil recebem novos investimentos...",
        "autor": "Agência Brasil",
        "data_publicacao": "2026-10-06T14:20:00",
        "imagem_url": None,
    },
    {
        "id": 6,
        "categoria": "mundo",
        "titulo": "Encontro Internacional Debate Mudanças Climáticas",
        "subtitulo": "Líderes mundiais se reúnem para definir novas metas",
        "conteudo": "Representantes de diversos países apresentam planos de ação...",
        "autor": "Mundo Hoje",
        "data_publicacao": "2026-10-06T08:00:00",
        "imagem_url": None,
    },
    {
        "id": 7,
        "categoria": "saude",
        "titulo": "Novas Pesquisas na Área de Medicina Preventiva",
        "subtitulo": "Estudos destacam a importância da alimentação e exercícios",
        "conteudo": "Pesquisadores apontam hábitos que aumentam a longevidade...",
        "autor": "Saúde & Bem-Estar",
        "data_publicacao": "2026-10-05T18:45:00",
        "imagem_url": None,
    },
    {
        "id": 8,
        "categoria": "entreterimento",
        "titulo": "Lançamentos de Filmes e Séries Deste Mês",
        "subtitulo": "Confira o que chega às plataformas de streaming",
        "conteudo": "A programação traz estreias aguardadas pelo público...",
        "autor": "Guia Cultural",
        "data_publicacao": "2026-10-06T12:00:00",
        "imagem_url": None,
    },
]

db_planos: List[dict] = [
    {
        "id": 1,
        "nome": "Plano Básico",
        "preco_mensal": 14.90,
        "recursos": [
            "Acesso a notícias ilimitadas",
            "Leitura sem anúncios básicos",
        ],
    },
    {
        "id": 2,
        "nome": "Plano Premium",
        "preco_mensal": 29.90,
        "recursos": [
            "Acesso total a todas as categorias",
            "Sem anúncios",
            "Newsletter exclusiva diária",
        ],
    },
]

# --- Rotas da API ---

@app.get("/", summary="Página Inicial da API")
def read_root():
    return {
        "mensagem": "API do Portal de Notícias rodando com sucesso!",
        "documentacao": "/docs",
        "categorias_disponiveis": CATEGORIAS_VALIDAS,
    }

@app.get("/noticias", response_model=List[Noticia], summary="Listar Notícias Atualizadas")
def listar_noticias(
    categoria: Optional[str] = Query(None, description="Filtrar por categoria (ex: esporte, economia, tecnologia)"),
    limite: int = Query(10, ge=1, le=50, description="Quantidade de notícias a retornar"),
):
    noticias = db_noticias
    if categoria:
        categoria_lower = categoria.lower()
        if categoria_lower not in CATEGORIAS_VALIDAS:
            raise HTTPException(status_code=400, detail=f"Categoria '{categoria}' é inválida.")
        noticias = [n for n in noticias if n["categoria"].lower() == categoria_lower]
    
    noticias_ordenadas = sorted(noticias, key=lambda x: x["data_publicacao"], reverse=True)
    return noticias_ordenadas[:limite]

@app.get("/noticias/categoria/{categoria}", response_model=List[Noticia], summary="Listar por Categoria Específica")
def obter_noticias_por_categoria(
    categoria: str = Path(..., description="Temas: esporte, economia, politica, brasil, mundo, saude, tecnologia, entreterimento")
):
    cat_norm = categoria.lower()
    if cat_norm not in CATEGORIAS_VALIDAS:
        raise HTTPException(status_code=404, detail=f"Tema/Categoria '{categoria}' não encontrado.")
    
    noticias = [n for n in db_noticias if n["categoria"].lower() == cat_norm]
    return sorted(noticias, key=lambda x: x["data_publicacao"], reverse=True)

@app.get("/noticias/{noticia_id}", response_model=Noticia, summary="Obter Detalhes de uma Notícia")
def obter_noticia(noticia_id: int = Path(..., ge=1)):
    for noticia in db_noticias:
        if noticia["id"] == noticia_id:
            return noticia
    raise HTTPException(status_code=404, detail="Notícia não encontrada.")

@app.post("/noticias/categoria/{categoria}", response_model=Noticia, status_code=201, summary="Adicionar Nova Notícia em uma Categoria")
def criar_noticia(categoria: str, noticia: NoticiaCriacao):
    cat_norm = categoria.lower()
    if cat_norm not in CATEGORIAS_VALIDAS:
        raise HTTPException(
            status_code=400,
            detail=f"Categoria '{categoria}' inválida. Escolha entre: {CATEGORIAS_VALIDAS}"
        )
    
    novo_id = max([n["id"] for n in db_noticias], default=0) + 1
    from datetime import datetime
    data_atual = datetime.now().isoformat()
    
    nova_noticia = {
        "id": novo_id,
        "categoria": cat_norm,
        "titulo": noticia.titulo,
        "subtitulo": noticia.subtitulo,
        "conteudo": noticia.conteudo,
        "autor": noticia.autor,
        "data_publicacao": data_atual,
        "imagem_url": noticia.imagem_url,
    }
    
    db_noticias.append(nova_noticia)
    return nova_noticia

@app.get("/assinatura/planos", response_model=List[PlanoAssinatura], summary="Listar Planos de Assinatura")
def listar_planos_assinatura():
    return db_planos

@app.post("/assinatura/assinar", response_model=RespostaAssinatura, status_code=201, summary="Solicitar Assinatura de Plano")
def solicitar_assinatura(dados: AssinaturaSolicitacao):
    plano_existe = any(p["id"] == dados.plano_id for p in db_planos)
    if not plano_existe:
        raise HTTPException(status_code=404, detail="Plano de assinatura não encontrado.")
    
    return RespostaAssinatura(
        mensagem="Solicitação de assinatura recebida com sucesso!",
        status="ativa",
        detalhes=dados
    )
