const API_BASE = localStorage.getItem('NEWS_API_URL') || 'http://localhost:3333/api';

async function carregarNoticias() {
  const grid = document.getElementById('newsGrid');
  if (!grid) return;
  grid.innerHTML = '<p>Carregando notícias...</p>';
  try {
    const res = await fetch(`${API_BASE}/noticias?limit=6`);
    const data = await res.json();
    const noticias = data.noticias || [];
    if (!noticias.length) {
      grid.innerHTML = '<p>Nenhuma notícia disponível no momento.</p>';
      return;
    }
    grid.innerHTML = noticias.map(n => `
      <article class="news-card">
        <div class="news-image">${n.categoria || 'NOTÍCIA'}</div>
        <div class="news-content">
          <span class="tag">${n.categoria || ''}</span>
          <h3>${escapeHtml(n.titulo || '')}</h3>
          <p>${escapeHtml(n.resumo || '')}</p>
        </div>
      </article>`).join('');
  } catch (e) {
    grid.innerHTML = '<p>Não foi possível conectar à API. Inicie o servidor em <strong>api</strong>.</p>';
  }
}
function escapeHtml(v){return String(v).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
carregarNoticias();
