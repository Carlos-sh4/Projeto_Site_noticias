// Arquivo de compatibilidade da estrutura original. Funcionalidades principais estão em app.js e theme.js.
