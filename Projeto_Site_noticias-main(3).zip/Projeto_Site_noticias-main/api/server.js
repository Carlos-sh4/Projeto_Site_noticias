require('dotenv').config();
const express=require('express');
const cors=require('cors');
const fs=require('fs');
const path=require('path');

const app=express();
app.use(cors());
app.use(express.json());

const PORT=process.env.PORT||3333;
const DATA=path.join(__dirname,'..','data','noticias.json');

function readNews(){try{return JSON.parse(fs.readFileSync(DATA,'utf8'))}catch{return[]}}

app.get('/api/health',(req,res)=>res.json({ok:true,service:'portal-noticias-api',version:'2.0.0'}));
app.get('/api/categorias',(req,res)=>res.json({categorias:['esportes','economia','politica','brasil','mundo','saude','tecnologia','entretenimento']}));
app.get('/api/noticias',(req,res)=>{
  let noticias=readNews();
  const {categoria,q,limit}=req.query;
  if(categoria) noticias=noticias.filter(n=>String(n.categoria).toLowerCase()===String(categoria).toLowerCase());
  if(q){const s=String(q).toLowerCase();noticias=noticias.filter(n=>[n.titulo,n.resumo,n.categoria].join(' ').toLowerCase().includes(s))}
  const lim=Math.min(Number(limit)||50,100);
  res.json({total:noticias.length,noticias:noticias.slice(0,lim),atualizado_em:new Date().toISOString()});
});
app.get('/api/busca',(req,res)=>{
  const q=String(req.query.q||'').trim().toLowerCase();
  const noticias=readNews().filter(n=>!q||[n.titulo,n.resumo,n.categoria,n.fonte].join(' ').toLowerCase().includes(q));
  res.json({q,total:noticias.length,noticias});
});

app.listen(PORT,()=>console.log(`API rodando em http://localhost:${PORT}`));
