# Projeto_Site_noticias-main — versão reconstruída

## Estrutura
- `index.html` — página inicial
- páginas de categorias: Brasil, Mundo, Esportes, Economia, Política, Saúde, Tecnologia e Entretenimento
- `css/` — estilos
- `js/` — scripts
- `img/` — imagens SVG de fallback
- `data/noticias.json` — dados locais de demonstração
- `api/` — API Node.js/Express

## Como executar a API
No terminal do VS Code:

```bash
cd api
npm install
npm start
```

A API ficará em:
`http://localhost:3333`

Endpoints:
- `/api/health`
- `/api/categorias`
- `/api/noticias`
- `/api/noticias?categoria=tecnologia`
- `/api/noticias?q=brasil`
- `/api/busca?q=tecnologia`

## Notícias realmente atualizadas
A versão reconstruída já deixa a API organizada para receber um provedor externo por meio das variáveis `NEWS_PROVIDER_URL` e `NEWS_API_KEY`. Os dados incluídos no ZIP são dados locais de demonstração; eles não devem ser confundidos com notícias reais em tempo real.

As imagens originais do ZIP anterior não estavam disponíveis no conteúdo recuperado, então foram usados SVGs de fallback para manter o projeto executável.
